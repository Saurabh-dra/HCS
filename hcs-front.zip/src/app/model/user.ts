export class User {
    id: number;
    regEmail: string;
    regPassword: string;
    frName: string;
    lsName: string;
    ctNumber: number;

    constructor(){}

}